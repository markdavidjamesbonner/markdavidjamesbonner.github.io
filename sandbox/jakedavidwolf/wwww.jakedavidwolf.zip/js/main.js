$(function() {
	$('button').donutRun();
});

//copy this to the end of your main JavaScript file